$(document).ready(function() {
    $('.main').hide();
    
    window.addEventListener('message', function(event) {
        let data = event.data;
        if (data.action === 'open') {
            $('.main').show();
            $('.playerName').text(data.playerName);
            $('.levelText').text('Nvl ' + data.level);
            $('.xp').text(data.xp + ' XP');
            
            // Wezel - Mostrar XP
            $('.job[data-job="wezel"] .price').text('$' + data.sprice);
            $('.job[data-job="wezel"] .max').text(data.wezelnStep + ' XP');
            
            // Cajas - Mostrar XP
            $('.job[data-job="cajas"] .price').text('$' + data.gprice);
            $('.job[data-job="cajas"] .max').text(data.boxStep + ' XP');
            
// En la parte donde se actualiza tecno, cambia:
$('.job[data-job="tecno"] .price').text('$' + data.wprice);
$('.job[data-job="tecno"] .max').text(data.techStep + ' XP');  // Cambiado de 'entregas' a 'XP'
            
        } else if (data.action === 'levelUp') {
            console.log('Subio de nivel!');
        }
    });

    $('.start').on('click', function() {
        let job = $(this).closest('.job').data('job');
        $.post('https://sh-entregas/selectJob', JSON.stringify({ selected: job }));
        $('.main').fadeOut(300);
        $.post('https://sh-entregas/close', JSON.stringify({}));
    });

    $(document).on('keyup', function(e) {
        if (e.key === 'Escape' || e.key === 'Backspace') {
            $('.main').fadeOut(300);
            $.post('https://sh-entregas/close', JSON.stringify({}));
        }
    });
});