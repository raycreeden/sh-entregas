-- server/deposito.lua
local QBCore = exports['qb-core']:GetCoreObject()

-- Evento para pagos INDIVIDUALES por cada entrega
RegisterServerEvent('sh-entregas:pagoIndividualTecno')
AddEventHandler('sh-entregas:pagoIndividualTecno', function(categoriaCorrecta, ganancia)
    local src = source
    local xPlayer = QBCore.Functions.GetPlayer(src)
    if not xPlayer then return end
    
    local amount = tonumber(ganancia) or 0
    
    if amount > 0 then
        -- Pago individual por entrega
        xPlayer.Functions.AddMoney('bank', amount, "Entrega tecno - " .. (categoriaCorrecta and "correcta" or "incorrecta"))
        

    end
end)

-- Evento para registrar entregas individuales (solo log)
RegisterServerEvent('sh-entregas:logEntregaTecno')
AddEventHandler('sh-entregas:logEntregaTecno', function(categoriaCorrecta, ganancia)
    local src = source
    local xPlayer = QBCore.Functions.GetPlayer(src)
    if not xPlayer then return end
    

end)

-- Evento para notificar que tecno finalizó
RegisterServerEvent('sh-entregas:notificarTecnoFinalizado')
AddEventHandler('sh-entregas:notificarTecnoFinalizado', function()
    local src = source
    
    TriggerClientEvent('sh-entregas:tecnoFinalizado', src)
end)