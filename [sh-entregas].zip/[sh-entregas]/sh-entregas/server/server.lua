-- server.lua (simplificado: callbacks y pago/xp)
local QBCore = exports['qb-core']:GetCoreObject()

QBCore.Functions.CreateCallback('sh-entregas:obtenerDatos', function(source, cb)
local src = source
local xPlayer = QBCore.Functions.GetPlayer(src)
if not xPlayer then return cb(nil) end

local identifier = xPlayer.PlayerData.citizenid or xPlayer.PlayerData.identifier

local result = MySQL.Sync.fetchAll('SELECT level, xp FROM sh_delivery WHERE identifier = ?', { identifier })
if result and result[1] then
    cb({
        nivel = tonumber(result[1].level) or 1,
        xp = tonumber(result[1].xp) or 0,
        nombre = xPlayer.PlayerData.charinfo.firstname .. " " .. xPlayer.PlayerData.charinfo.lastname
    })
else
    MySQL.Sync.execute('INSERT INTO sh_delivery (identifier, level, xp) VALUES (?, ?, ?)', { identifier, 1, 0 })
    cb({
        nivel = 1,
        xp = 0,
        nombre = xPlayer.PlayerData.charinfo.firstname .. " " .. xPlayer.PlayerData.charinfo.lastname
    })
end

end)

RegisterNetEvent('sh-entregas:entregarPago')
AddEventHandler('sh-entregas:entregarPago', function(jobName, money, xp)
local src = source
local xPlayer = QBCore.Functions.GetPlayer(src)
if not xPlayer then return end

local identifier = xPlayer.PlayerData.citizenid or xPlayer.PlayerData.identifier
local amount = tonumber(money) or 0
if amount > 0 then
    xPlayer.Functions.AddMoney('bank', amount, "Trabajo de entrega - " .. tostring(jobName))
end

local addXP = tonumber(xp) or 0

local result = MySQL.Sync.fetchAll('SELECT level, xp FROM sh_delivery WHERE identifier = ?', { identifier })
if result and result[1] then
    local curXP = tonumber(result[1].xp) or 0
    local curLevel = tonumber(result[1].level) or 1
    local newXP = curXP + addXP

    -- determinar xp necesaria para subir (si existe en Config)
    local xpRequired = 200
    if Config and Config.Trabajos and Config.Trabajos.ajustes and Config.Trabajos.ajustes.niveles and Config.Trabajos.ajustes.niveles[curLevel] then
        xpRequired = Config.Trabajos.ajustes.niveles[curLevel].siguienteNivel or xpRequired
    end

    if newXP >= xpRequired then
        local nextLevel = math.min(curLevel + 1, 10)
        MySQL.Sync.execute('UPDATE sh_delivery SET xp = ?, level = ? WHERE identifier = ?', { newXP, nextLevel, identifier })
        TriggerClientEvent('sh-entregas:levelUpNotify', src)
    else
        MySQL.Sync.execute('UPDATE sh_delivery SET xp = ? WHERE identifier = ?', { newXP, identifier })
    end
else
    MySQL.Sync.execute('INSERT INTO sh_delivery (identifier, level, xp) VALUES (?, ?, ?)', { identifier, 1, addXP })
end

end)

-- Añade este evento nuevo para tecno (después del evento 'sh-entregas:entregarPago')
RegisterNetEvent('sh-entregas:entregarPagoTecno')
AddEventHandler('sh-entregas:entregarPagoTecno', function(pagoGlobal, xpGlobal, gananciasIndividuales)
    local src = source
    local xPlayer = QBCore.Functions.GetPlayer(src)
    if not xPlayer then return end

    local identifier = xPlayer.PlayerData.citizenid or xPlayer.PlayerData.identifier
    
    -- 1. PAGO GLOBAL por completar el trabajo
    local amountGlobal = tonumber(pagoGlobal) or 0
    if amountGlobal > 0 then
        xPlayer.Functions.AddMoney('bank', amountGlobal, "Completar trabajo tecno - Bonus")
    end
    
    -- 2. XP por completar
    local addXP = tonumber(xpGlobal) or 0
    
    -- 3. Actualizar XP y nivel
    local result = MySQL.Sync.fetchAll('SELECT level, xp FROM sh_delivery WHERE identifier = ?', { identifier })
    if result and result[1] then
        local curXP = tonumber(result[1].xp) or 0
        local curLevel = tonumber(result[1].level) or 1
        local newXP = curXP + addXP

        -- determinar xp necesaria para subir
        local xpRequired = 200
        if Config and Config.Trabajos and Config.Trabajos.ajustes and Config.Trabajos.ajustes.niveles and Config.Trabajos.ajustes.niveles[curLevel] then
            xpRequired = Config.Trabajos.ajustes.niveles[curLevel].siguienteNivel or xpRequired
        end

        if newXP >= xpRequired then
            local nextLevel = math.min(curLevel + 1, 10)
            MySQL.Sync.execute('UPDATE sh_delivery SET xp = ?, level = ? WHERE identifier = ?', { newXP, nextLevel, identifier })
            TriggerClientEvent('sh-entregas:levelUpNotify', src)
        else
            MySQL.Sync.execute('UPDATE sh_delivery SET xp = ? WHERE identifier = ?', { newXP, identifier })
        end
    else
        MySQL.Sync.execute('INSERT INTO sh_delivery (identifier, level, xp) VALUES (?, ?, ?)', { identifier, 1, addXP })
    end
    
    -- 4. Log del total
   

end)

-- Mantén el evento original para wezel y cajas
RegisterNetEvent('sh-entregas:entregarPago')
AddEventHandler('sh-entregas:entregarPago', function(jobName, money, xp)
    local src = source
    local xPlayer = QBCore.Functions.GetPlayer(src)
    if not xPlayer then return end

    local identifier = xPlayer.PlayerData.citizenid or xPlayer.PlayerData.identifier
    local amount = tonumber(money) or 0
    
    -- SOLO para wezel y cajas
    if jobName ~= 'tecno' and amount > 0 then
        xPlayer.Functions.AddMoney('bank', amount, "Trabajo de entrega - " .. tostring(jobName))
    end

    local addXP = tonumber(xp) or 0

    -- ... (el resto del código para XP permanece igual)
    local result = MySQL.Sync.fetchAll('SELECT level, xp FROM sh_delivery WHERE identifier = ?', { identifier })
    if result and result[1] then
        local curXP = tonumber(result[1].xp) or 0
        local curLevel = tonumber(result[1].level) or 1
        local newXP = curXP + addXP

        local xpRequired = 200
        if Config and Config.Trabajos and Config.Trabajos.ajustes and Config.Trabajos.ajustes.niveles and Config.Trabajos.ajustes.niveles[curLevel] then
            xpRequired = Config.Trabajos.ajustes.niveles[curLevel].siguienteNivel or xpRequired
        end

        if newXP >= xpRequired then
            local nextLevel = math.min(curLevel + 1, 10)
            MySQL.Sync.execute('UPDATE sh_delivery SET xp = ?, level = ? WHERE identifier = ?', { newXP, nextLevel, identifier })
            TriggerClientEvent('sh-entregas:levelUpNotify', src)
        else
            MySQL.Sync.execute('UPDATE sh_delivery SET xp = ? WHERE identifier = ?', { newXP, identifier })
        end
    else
        MySQL.Sync.execute('INSERT INTO sh_delivery (identifier, level, xp) VALUES (?, ?, ?)', { identifier, 1, addXP })
    end
end)

-- Añade esto en server.lua, después de los otros eventos:
RegisterNetEvent('sh-entregas:limpiarTrabajoTecno')
AddEventHandler('sh-entregas:limpiarTrabajoTecno', function()
    local src = source
    -- Notificar al cliente que limpie su trabajo local
    TriggerClientEvent('sh-entregas:limpiarTrabajoLocal', src)
end)