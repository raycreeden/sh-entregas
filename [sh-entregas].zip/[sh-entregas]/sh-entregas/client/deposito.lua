-- client/deposito.lua
local QBCore = exports['qb-core']:GetCoreObject()

local TecnoJob = {
    activo = false,
    puntosRecoleccion = {},
    propsEnMundo = {},
    propEnMano = nil,
    propCategoria = nil,
    blips = {},
    depositos = {},
    propsEntregados = 0,
    propsTotales = 0,
    ganancias = 0,
    propsPorEntregar = {}
}

local function RestaurarRopaTrabajo()
    local ped = PlayerPedId()
    local success, result = pcall(function()
        return exports[GetCurrentResourceName()]:RestaurarRopaTrabajo()
    end)
    
    if not success then
        if _G.RestaurarRopaTrabajo then
            _G.RestaurarRopaTrabajo()
        end
    end
end

local function Notificar(texto, tipo)
    QBCore.Functions.Notify(texto, tipo or "primary")
end

local function LimpiarProp()
    if TecnoJob.propEnMano and DoesEntityExist(TecnoJob.propEnMano) then
        DeleteEntity(TecnoJob.propEnMano)
        TecnoJob.propEnMano = nil
        TecnoJob.propCategoria = nil
    end
    ClearPedTasks(PlayerPedId())
    
    -- Habilitar controles de vehículos nuevamente
    EnableControlAction(0, 23, true) -- Tecla F
    EnableControlAction(0, 75, true) -- Tecla F (salir)
    EnableControlAction(0, 36, true) -- Tecla CTRL
    EnableControlAction(0, 58, true) -- Tecla G
end

local function CrearBlip(coords, texto, sprite, color)
    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blip, sprite or Config.Tecno.config.blipSprite)
    SetBlipColour(blip, color or Config.Tecno.config.blipColor)
    SetBlipScale(blip, Config.Tecno.config.blipScale)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(texto)
    EndTextCommandSetBlipName(blip)
    return blip
end

local function CrearPuntosRecoleccion()
    for i, punto in ipairs(Config.Tecno.puntosRecoleccion) do
        TecnoJob.puntosRecoleccion[i] = {
            nombre = punto.nombre,
            posicion = punto.posicion,
            propsDisponibles = punto.maxProps or 10,
            id = i
        }
        
        -- Crear blip para el punto de recolección
        TecnoJob.blips["punto_"..i] = CrearBlip(
            punto.posicion, 
            punto.nombre, 
            Config.Tecno.config.blipSpriteRecoleccion or 477, 
            Config.Tecno.config.blipColorRecoleccion or 2
        )
        
        -- Crear marcador para el punto de recolección
        CreateThread(function()
            while TecnoJob.activo do
                local posPunto = punto.posicion
                DrawMarker(
                    2, 
                    posPunto.x, posPunto.y, posPunto.z + 1.0, 
                    0,0,0, 0,0,0, 
                    0.6,0.6,0.6, 
                    50,255,50,100, 
                    false, true, 2, false, false, false, false
                )
                Wait(0)
            end
        end)
    end
end

local function GenerarPropsPorPunto()
    local propsDisponibles = {}
    
    -- Crear lista de props con categorías asignadas aleatoriamente
    for _, propData in ipairs(Config.Tecno.props) do
        local categoria = propData.categoria
        if categoria == 'todas' then
            -- Asignar categoría aleatoria de las disponibles
            local categorias = {}
            for _, dep in ipairs(Config.Tecno.depositos) do
                categorias[#categorias + 1] = dep.categoria
            end
            categoria = categorias[math.random(#categorias)]
        end
        
        propsDisponibles[#propsDisponibles + 1] = {
            prop = propData.prop,
            categoria = categoria,
            nombre = propData.nombre
        }
    end
    
    -- Mezclar aleatoriamente
    for i = #propsDisponibles, 2, -1 do
        local j = math.random(i)
        propsDisponibles[i], propsDisponibles[j] = propsDisponibles[j], propsDisponibles[i]
    end
    
    return propsDisponibles
end

local function IniciarTecno()
    TecnoJob.activo = true
    TecnoJob.propsTotales = Config.Tecno.config.totalProps
    TecnoJob.propsEntregados = 0
    TecnoJob.ganancias = 0
    TecnoJob.propsPorEntregar = GenerarPropsPorPunto()
    
    -- Crear puntos de recolección
    CrearPuntosRecoleccion()
    
    -- Crear blips para depósitos (solo visibles para el jugador)
    for _, deposito in ipairs(Config.Tecno.depositos) do
        TecnoJob.blips["dep_"..deposito.categoria] = CrearBlip(deposito.posicion, deposito.nombre, 478, 2)
        TecnoJob.depositos[deposito.categoria] = deposito
    end
    
    Notificar(Config.Textos.tecno_iniciado, "success")
    
    -- Thread para BLOQUEAR ENTRADA A VEHÍCULOS mientras tiene prop
    CreateThread(function()
        while TecnoJob.activo do
            local ped = PlayerPedId()
            
            -- Si tiene un prop en mano, bloquear entrada a vehículos
            if TecnoJob.propEnMano then
                DisableControlAction(0, 23, true) -- Tecla F (entrar/salir vehículo)
                DisableControlAction(0, 75, true) -- Tecla F (salir vehículo)
                DisableControlAction(0, 36, true) -- Tecla CTRL DUCK/COVER
                
                -- También prevenir entrar a vehículos con E si el jugador está muy cerca
                DisableControlAction(0, 58, true) -- Tecla G (contextual)
                
                -- Si intenta entrar a un vehículo, notificar
                if IsPedTryingToEnterALockedVehicle(ped) or IsControlJustPressed(0, 23) then
                    Notificar("No puedes subirte a un vehículo mientras llevas mercadería", "error")
                end
            end
            
            Wait(0)
        end
    end)
    
    -- Iniciar thread principal
    CreateThread(function()
        while TecnoJob.activo do
            local ped = PlayerPedId()
            local pos = GetEntityCoords(ped)
            local wait = 1000
            
            -- RECOLECTAR PROPS DE LOS PUNTOS DE RECOLECCIÓN
            if not TecnoJob.propEnMano then
                for i, puntoData in ipairs(TecnoJob.puntosRecoleccion) do
                    local posPunto = puntoData.posicion
                    local distancia = #(pos - posPunto)
                    
                    if distancia < 10 and puntoData.propsDisponibles > 0 then
                        wait = 0
                        
                        if distancia < 1.5 then
                            if IsPedInAnyVehicle(ped, false) then
                                Texto3D(posPunto, Config.Textos.tecno_salir_vehiculo)
                            else
                                Texto3D(posPunto, Config.Textos.tecno_recolectar)
                                
                                if IsControlJustReleased(0, 38) then -- Tecla E
                                    -- Verificar que no esté en vehículo
                                    if IsPedInAnyVehicle(ped, false) then
                                        Notificar("Debes salir del vehículo para recoger mercadería", "error")
                                    else
                                        -- Verificar si hay props disponibles para entregar
                                        if #TecnoJob.propsPorEntregar == 0 then
                                            Notificar("No hay más mercadería para recolectar", "error")
                                        else
                                            -- Seleccionar prop aleatorio de los disponibles
                                            local propIndex = math.random(#TecnoJob.propsPorEntregar)
                                            local propData = TecnoJob.propsPorEntregar[propIndex]
                                            
                                            -- Crear prop en manos del jugador
                                            RequestModel(propData.prop)
                                            while not HasModelLoaded(propData.prop) do Wait(10) end
                                            
                                            local obj = CreateObject(GetHashKey(propData.prop), pos.x, pos.y, pos.z, true, true, true)
                                            AttachEntityToEntity(obj, ped, GetPedBoneIndex(ped, 28422), 0.0, -0.15, -0.25, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
                                            TecnoJob.propEnMano = obj
                                            TecnoJob.propCategoria = propData.categoria
                                            
                                            -- Notificar categoría
                                            Notificar(string.format(Config.Textos.tecno_recogida, propData.nombre), "info")
                                            
                                            -- Reducir props disponibles en el punto
                                            puntoData.propsDisponibles = puntoData.propsDisponibles - 1
                                            
                                            -- Remover prop de la lista
                                            table.remove(TecnoJob.propsPorEntregar, propIndex)
                                            
                                            PlayCarryAnim()
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            else
                -- VERIFICAR SI EL JUGADOR SE SUBIÓ A UN VEHÍCULO (por si acaso)
                if IsPedInAnyVehicle(ped, false) then
                    Notificar("¡No puedes conducir con mercadería en las manos! Suelta la caja primero.", "error")
                    -- Forzar salida del vehículo
                    ClearPedTasksImmediately(ped)
                    TaskLeaveAnyVehicle(ped, 0, 0)
                    Wait(500)
                end
                
                -- ENTREGAR PROPS EN DEPÓSITOS
                for categoria, deposito in pairs(TecnoJob.depositos) do
                    local distancia = #(pos - deposito.posicion)
                    
                    if distancia < 10 then
                        wait = 0
                        
                        DrawMarker(2, deposito.posicion.x, deposito.posicion.y, deposito.posicion.z + 0.5,
                            0,0,0, 0,0,0, 0.6,0.6,0.6, 255,50,50,100, false, true, 2, false, false, false, false)
                        
                        if distancia < 2.5 then
                            local texto = string.format(Config.Textos.tecno_entregar, deposito.nombre)
                            if TecnoJob.propCategoria == categoria then
                                texto = texto .. " ✅"
                            else
                                texto = texto .. " ❌"
                            end
                            
                            Texto3D(vector3(deposito.posicion.x, deposito.posicion.y, deposito.posicion.z + 1.0), texto)
                            
                            if IsControlJustReleased(0, 38) then -- Tecla E
                                -- Verificar que no esté en vehículo
                                if IsPedInAnyVehicle(ped, false) then
                                    Notificar("Debes salir del vehículo para entregar", "error")
                                else
                                    -- Calcular pago INDIVIDUAL
                                    local pagoIndividual = 0
                                    if TecnoJob.propCategoria == categoria then
                                        pagoIndividual = Config.Tecno.config.pagoPorEntregaCorrecta
                                        Notificar(string.format(Config.Textos.tecno_entrega_correcta, pagoIndividual), "success")
                                    else
                                        pagoIndividual = Config.Tecno.config.pagoPorEntregaIncorrecta
                                        Notificar(Config.Textos.tecno_entrega_incorrecta, "error")
                                    end
                                    
                                    -- PAGO INDIVIDUAL INMEDIATO
                                    if pagoIndividual > 0 then
                                        TriggerServerEvent('sh-entregas:pagoIndividualTecno', TecnoJob.propCategoria == categoria, pagoIndividual)
                                    end
                                    
                                    -- Log de la entrega
                                    TriggerServerEvent('sh-entregas:logEntregaTecno', TecnoJob.propCategoria == categoria, pagoIndividual)
                                    
                                    -- Eliminar prop
                                    LimpiarProp()
                                    
                                    -- Actualizar contadores
                                    TecnoJob.propsEntregados = TecnoJob.propsEntregados + 1
                                    TecnoJob.gananciasIndividuales = (TecnoJob.gananciasIndividuales or 0) + pagoIndividual
                                    
                                    -- Notificar progreso
                                    Notificar(string.format(Config.Textos.tecno_props_restantes, 
                                        TecnoJob.propsTotales - TecnoJob.propsEntregados, TecnoJob.propsTotales), "info")
                                    
                                    -- Verificar si se completó el trabajo
                                    if TecnoJob.propsEntregados >= TecnoJob.propsTotales then
                                        -- PAGO GLOBAL al finalizar (según nivel)
                                        QBCore.Functions.TriggerCallback('sh-entregas:obtenerDatos', function(res)
                                            if not res then return end
                                            
                                            local nivel = res.nivel
                                            local pagoGlobal = 0
                                            
                                            -- Buscar el pago según nivel en Config
                                            for _, ajuste in ipairs(Config.Trabajos.ajustes.tecno) do
                                                if ajuste.nivel == nivel then
                                                    pagoGlobal = ajuste.precio
                                                    break
                                                end
                                            end
                                            
                                            -- Si no encuentra, usar el primero
                                            if pagoGlobal == 0 and #Config.Trabajos.ajustes.tecno > 0 then
                                                pagoGlobal = Config.Trabajos.ajustes.tecno[1].precio
                                            end
                                            
                                            -- XP según nivel
                                            local xpGlobal = 0
                                            for _, ajuste in ipairs(Config.Trabajos.ajustes.tecno) do
                                                if ajuste.nivel == nivel then
                                                    xpGlobal = ajuste.xp
                                                    break
                                                end
                                            end
                                            
                                            -- Enviar pago global
                                            TriggerServerEvent('sh-entregas:entregarPagoTecno', pagoGlobal, xpGlobal, TecnoJob.gananciasIndividuales or 0)
                                            
                                            -- Notificar al jugador
                                            Notificar(string.format("¡Trabajo completado! Ganaste: $%d (entregas) + $%d (completado) = $%d total", 
                                                TecnoJob.gananciasIndividuales or 0, pagoGlobal, 
                                                (TecnoJob.gananciasIndividuales or 0) + pagoGlobal), "success")
                                            
                                            FinalizarTecno()
                                        end)
                                        break
                                    end
                                end
                            end
                        end
                    end
                end
            end
            
            Wait(wait)
        end
    end)
end

function Texto3D(coords, texto)
    local onScreen, x, y = World3dToScreen2d(coords.x, coords.y, coords.z)
    if onScreen then
        -- Configuración mejorada para legibilidad
        SetTextScale(0.35, 0.35)
        SetTextFont(4) -- Fuente más gruesa
        SetTextProportional(1)
        
        -- COLOR AMARILLO CON CONTRASTE
        SetTextColour(255, 215, 0, 255) -- Amarillo dorado (RGB: 255, 215, 0)
        
        -- Añadir efectos para mejor visibilidad
        SetTextOutline() -- Borde negro alrededor del texto
        SetTextDropShadow(2, 0, 0, 0, 200) -- Sombra para contraste
        
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(texto)
        DrawText(x, y)
    end
end

function PlayCarryAnim()
    local dict = Config.Anims.carryIdle.dict
    local name = Config.Anims.carryIdle.name
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do Wait(5) end
    TaskPlayAnim(PlayerPedId(), dict, name, 2.0, 2.0, -1, 49, 0, false, false, false)
end

function FinalizarTecno()
    if not TecnoJob.activo then 
        return 
    end
    
    TecnoJob.activo = false
    
    -- Limpiar props en mano
    LimpiarProp()
    
    -- Eliminar blips (forma segura sin DoesBlipExist)
    for key, blip in pairs(TecnoJob.blips) do
        if blip then
            RemoveBlip(blip)
            TecnoJob.blips[key] = nil
        end
    end
    
    -- Limpiar todas las props en el mundo
    for i, prop in ipairs(TecnoJob.propsEnMundo) do
        if prop and DoesEntityExist(prop) then
            SetEntityAsMissionEntity(prop, true, true)
            DeleteObject(prop)
            DeleteEntity(prop)
        end
    end
    
    -- Limpiar variables
    TecnoJob.puntosRecoleccion = {}
    TecnoJob.propsEnMundo = {}
    TecnoJob.depositos = {}
    TecnoJob.propsPorEntregar = {}
    TecnoJob.propEnMano = nil
    TecnoJob.propCategoria = nil
    TecnoJob.propsEntregados = 0
    TecnoJob.propsTotales = 0
    TecnoJob.ganancias = 0
    TecnoJob.blips = {}
    
    -- Restaurar ropa
    if RestaurarRopaTrabajo then
        RestaurarRopaTrabajo()
    else
        local success, result = pcall(function()
            return exports[GetCurrentResourceName()]:RestaurarRopaTrabajo()
        end)
        if not success and _G.RestaurarRopaTrabajo then
            _G.RestaurarRopaTrabajo()
        end
    end
    
    -- Notificar al cliente principal que limpie su trabajo
    TriggerEvent('sh-entregas:tecnoFinalizado')
    
    -- También disparar evento global para el recurso
    TriggerServerEvent('sh-entregas:notificarTecnoFinalizado')
    
end

-- Export para ser llamado desde client.lua
exports('StartTecno', IniciarTecno)
exports('FinalizarTecno', FinalizarTecno)

-- Comando para cancelar (mejorado)
RegisterCommand('cancelartecno', function()
    if TecnoJob.activo then
        Notificar("Trabajo de Reposicion cancelado", "error")
        FinalizarTecno()
    else
        Notificar("No tienes trabajo de Reposicion activo", "error")
    end
end)

-- Cleanup al detener el recurso (mejorado)
AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        if TecnoJob.activo then
            FinalizarTecno()
        end
    end
end)

-- También limpia al cambiar de personaje o desconectar
AddEventHandler('playerDropped', function()
    if TecnoJob.activo then
        FinalizarTecno()
    end
end)

-- Añade esta función en deposito.lua, al final con las otras exports
local function EliminarVehiculosTecno()
    -- Función vacía ahora (no elimina vehículos)
    -- Se mantiene por compatibilidad con client.lua
end

-- Export para ser llamado desde client.lua
exports('StartTecno', IniciarTecno)
exports('FinalizarTecno', FinalizarTecno)
-- En deposito.lua, al final:
exports('EliminarVehiculosTecno', EliminarVehiculosTecno)  -- <-- NUEVA EXPORT