-- client/client.lua
local QBCore = exports['qb-core']:GetCoreObject()
local ropaCivil = nil

local Trabajo = {
    activo = false,
    job = nil,
    precio = 0,
    xp = 0,
    vehiculo = nil,
    placa = nil,
    punto = 0,
    periodicosEnMano = 0,
    periodicosEnCamioneta = 0,
    cajasEnMano = 0,
    cajasEnCamioneta = 0,
    blip = nil,
    propEnMano = nil
}

local function Notificar(texto, tipo) QBCore.Functions.Notify(texto, tipo) end

-- NUEVA FUNCIÓN PARA MOSTRAR DATOS EN INTERFAZ
local function ActualizarDatosInterfaz(res)
    local nivel = res.nivel
    
    local function calcularPrecio(trabajo, nivel)
        local ajustes = Config.Trabajos.ajustes[trabajo]
        if not ajustes then return 0 end
        
        for _, ajuste in ipairs(ajustes) do
            if ajuste.nivel == nivel then
                return ajuste.precio
            end
        end
        
        return ajustes[#ajustes] and ajustes[#ajustes].precio or 0
    end
    
    -- NUEVO: Función para obtener XP según trabajo y nivel
    local function obtenerXP(trabajo, nivel)
        local ajustes = Config.Trabajos.ajustes[trabajo]
        if not ajustes then return 0 end
        
        for _, ajuste in ipairs(ajustes) do
            if ajuste.nivel == nivel then
                return ajuste.xp
            end
        end
        
        return ajustes[#ajustes] and ajustes[#ajustes].xp or 0
    end
    
SendNUIMessage({
    action = 'open',
    playerName = res.nombre,
    level = res.nivel,
    xp = res.xp,
    sprice = calcularPrecio('wezel', nivel),
    wezelnStep = obtenerXP('wezel', nivel),  -- CAMBIADO: XP, no entregas
    gprice = calcularPrecio('cajas', nivel),
    boxStep = obtenerXP('cajas', nivel),  -- XP que se gana
     wprice = calcularPrecio('tecno', nivel),  -- Cambiado de 0 a calcularPrecio
    techStep = obtenerXP('tecno', nivel)      -- Muestra XP para tecno (no entregas)
})
end

local function AbrirInterfaz()
    if Trabajo.activo then Notificar(Config.Textos.yaTrabajas, "error") return end
    
    QBCore.Functions.TriggerCallback('sh-entregas:obtenerDatos', function(res)
        if not res then return end
        ActualizarDatosInterfaz(res)
        SetNuiFocus(true, true)
    end)
end

-- NUEVO: SELECCIÓN DE TRABAJO CON SOPORTE PARA CAJAS
-- Reemplaza TODO el bloque del RegisterNUICallback('selectJob' con esto:
RegisterNUICallback('selectJob', function(data, cb)
    local job = data.selected
    
    QBCore.Functions.TriggerCallback('sh-entregas:obtenerDatos', function(res)
        if not res then return cb('ok') end
        local nivel = res.nivel
        
        local function obtenerAjuste(trabajo, nivelActual)
            local ajustesTabla = Config.Trabajos.ajustes[trabajo]
            if not ajustesTabla then return nil end
            
            for _, ajuste in ipairs(ajustesTabla) do
                if ajuste.nivel == nivelActual then
                    return ajuste
                end
            end
            
            return ajustesTabla[#ajustesTabla]
        end
        
        local ajuste = obtenerAjuste(job, nivel)
        if not ajuste then
            Notificar("Error configurando trabajo", "error")
            return cb('ok')
        end
        
        -- Configurar trabajo con variables específicas
        Trabajo.activo = true
        Trabajo.job = job
        Trabajo.precio = ajuste.precio
        Trabajo.xp = ajuste.xp
        Trabajo.punto = 0
        
        -- INICIALIZAR VARIABLES ESPECÍFICAS SEGÚN TRABAJO
        if job == 'wezel' then
            Trabajo.periodicosEnMano = 0
            Trabajo.periodicosEnCamioneta = 0
            Trabajo.cajasEnMano = 0
            Trabajo.cajasEnCamioneta = 0
        elseif job == 'cajas' then
            Trabajo.cajasEnMano = 0
            Trabajo.cajasEnCamioneta = 0
            Trabajo.periodicosEnMano = 0
            Trabajo.periodicosEnCamioneta = 0
        elseif job == 'tecno' then
            Trabajo.periodicosEnMano = 0
            Trabajo.periodicosEnCamioneta = 0
            Trabajo.cajasEnMano = 0
            Trabajo.cajasEnCamioneta = 0
        end
        
        PonerRopaTrabajo()
        SetNuiFocus(false, false)
        
        -- EJECUTAR EL TRABAJO CORRESPONDIENTE
        if job == 'wezel' then
            StartWezel()
        elseif job == 'cajas' then
            StartCajas()
        elseif job == 'tecno' then
            -- Iniciar trabajo tecno usando exports
            exports[GetCurrentResourceName()]:StartTecno()
        else
            Notificar("Este trabajo aún no está implementado", "error")
            Trabajo.activo = false
        end
        
        cb('ok')
    end)
end)

RegisterNUICallback('close', function(_, cb) SetNuiFocus(false, false) cb('ok') end)

local function CrearBlip(coords, texto)
    if Trabajo.blip then RemoveBlip(Trabajo.blip) end
    Trabajo.blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(Trabajo.blip, 478)
    SetBlipColour(Trabajo.blip, 5)
    SetBlipRoute(Trabajo.blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(texto)
    EndTextCommandSetBlipName(Trabajo.blip)
end

-- NUEVA FUNCIÓN PARA CREAR VEHÍCULO SEGÚN TRABAJO
local function CrearVehiculo(jobType)
    local modelo = Config.Vehiculos[jobType]
    local spawn = Config.Empresa.ubicacionVehiculo[jobType]
    
    if not modelo or not spawn then
        Notificar("Error: configuración de vehículo no encontrada", "error")
        return nil
    end
    
    RequestModel(modelo)
    while not HasModelLoaded(modelo) do Wait(10) end
    
    local veh = CreateVehicle(GetHashKey(modelo), spawn.x, spawn.y, spawn.z, spawn.w, true, false)
    local placa = "DEL" .. math.random(1000, 9999)
    SetVehicleNumberPlateText(veh, placa)
    SetVehicleEngineOn(veh, true, true, true)
    
    -- Aplicar mods según el modelo
    local modsConf = Config.VehicleMods[modelo]
    if modsConf then
        SetVehicleColours(veh, modsConf.primaryColor or 0, modsConf.secondaryColor or 0)
        SetVehicleExtraColours(veh, modsConf.rimColor or 0, 0)
        SetVehicleModKit(veh, 0)
        if modsConf.wheelType then SetVehicleWheelType(veh, modsConf.wheelType) end
        if modsConf.wheelIndex then SetVehicleMod(veh, 23, modsConf.wheelIndex, false) end
        if modsConf.livery then SetVehicleLivery(veh, modsConf.livery) end
        if modsConf.mods then
            for k,v in pairs(modsConf.mods) do
                SetVehicleMod(veh, tonumber(k), tonumber(v), false)
            end
        end
        if modsConf.extras then
            for extraId, enabled in pairs(modsConf.extras) do
                SetVehicleExtra(veh, tonumber(extraId), enabled and 0 or 1)
            end
        end
    end
    
    TriggerEvent("vehiclekeys:client:SetOwner", placa)
    Trabajo.vehiculo = veh
    Trabajo.placa = placa
    SetPedIntoVehicle(PlayerPedId(), veh, -1)
    return veh
end

local function EliminarVehiculo()
    if Trabajo.vehiculo and DoesEntityExist(Trabajo.vehiculo) then
        DeleteVehicle(Trabajo.vehiculo)
        Trabajo.vehiculo = nil
        Trabajo.placa = nil
    end
end

local function LimpiarProp()
    if Trabajo.propEnMano and DoesEntityExist(Trabajo.propEnMano) then
        DeleteEntity(Trabajo.propEnMano)
        Trabajo.propEnMano = nil
    end
    ClearPedTasks(PlayerPedId())
end

function PonerRopaTrabajo()
    local ped = PlayerPedId()

    if not ropaCivil then
        ropaCivil = {}
        for i = 0, 11 do
            ropaCivil[i] = {
                drawable = GetPedDrawableVariation(ped, i),
                texture = GetPedTextureVariation(ped, i)
            }
        end
        for i = 0, 7 do
            ropaCivil["prop"..i] = {
                drawable = GetPedPropIndex(ped, i),
                texture = GetPedPropTextureIndex(ped, i)
            }
        end
    end

    local esHombre = (GetEntityModel(ped) == GetHashKey("mp_m_freemode_01"))
    local genero = esHombre and "male" or "female"
    local ropa = Config.RopaTrabajo[genero]
    if not ropa then return end

    for _, v in pairs(ropa) do
        if v.component then
            SetPedComponentVariation(ped, v.component, v.drawable, v.texture, 0)
        elseif v.prop then
            ClearPedProp(ped, v.prop)
            if v.drawable ~= -1 then
                SetPedPropIndex(ped, v.prop, v.drawable, v.texture, true)
            end
        end
    end
end

function RestaurarRopaTrabajo()
    if not ropaCivil then return end
    local ped = PlayerPedId()
    
    for i = 0, 11 do
        local data = ropaCivil[i]
        if data then
            SetPedComponentVariation(ped, i, data.drawable, data.texture, 0)
        end
    end
    
    for i = 0, 7 do
        local data = ropaCivil["prop"..i]
        ClearPedProp(ped, i)
        if data and data.drawable ~= -1 then
            SetPedPropIndex(ped, i, data.drawable, data.texture, true)
        end
    end
    
    ropaCivil = nil
end

local function PlayCarryAnim()
    local dict = Config.Anims.carryIdle.dict
    local name = Config.Anims.carryIdle.name
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do Wait(5) end
    TaskPlayAnim(PlayerPedId(), dict, name, 2.0, 2.0, -1, 49, 0, false, false, false)
end

local function Texto3D(coords, texto)
    local onScreen, x, y = World3dToScreen2d(coords.x, coords.y, coords.z)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(texto)
        DrawText(x, y)
    end
end

-- ==============================
-- TRABAJO DE CAJAS (NUEVO)
-- ==============================
function StartCajas()
    local veh = CrearVehiculo('cajas')
    if not veh then
        Trabajo.activo = false
        return
    end
    
    CrearBlip(Config.Puntos.recogerCajas, "Recoger cajas")
    Notificar("Ve a recoger " .. #Config.Puntos.entregasCajas .. " cajas", "success")
    
    CreateThread(function()
        while Trabajo.activo and Trabajo.job == 'cajas' do
            local ped = PlayerPedId()
            local pos = GetEntityCoords(ped)
            local wait = 1000
            
            -- FASE 1: RECOGER CAJAS
            if Trabajo.cajasEnCamioneta < #Config.Puntos.entregasCajas then
                local dist = #(pos - Config.Puntos.recogerCajas)
                if dist < 10 then
                    wait = 0
                    DrawMarker(2, Config.Puntos.recogerCajas.x, Config.Puntos.recogerCajas.y, Config.Puntos.recogerCajas.z + 0.2, 
                        0,0,0, 0,0,0, 0.6,0.6,0.6, 255,50,50,100, false, true, 2, false, false, false, false)
                    
                    if dist < 2 then
                        local faltan = #Config.Puntos.entregasCajas - Trabajo.cajasEnCamioneta
                        Texto3D(vector3(Config.Puntos.recogerCajas.x, Config.Puntos.recogerCajas.y, Config.Puntos.recogerCajas.z+0.5), 
                            "[E] Recoger caja ("..faltan.." faltan)")
                        
                        if IsControlJustReleased(0, 38) then
                            if Trabajo.cajasEnMano == 0 then
                                LimpiarProp()
                                local propHash = GetHashKey(Config.Props.boxProp) -- 'prop_hat_box_06'
                                RequestModel(propHash)
                                while not HasModelLoaded(propHash) do Wait(5) end
                                
                                local obj = CreateObject(propHash, pos.x, pos.y, pos.z, true, true, true)
                                AttachEntityToEntity(obj, ped, GetPedBoneIndex(ped, 28422), 0.0, -0.15, -0.25, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
                                Trabajo.propEnMano = obj
                                
                                Trabajo.cajasEnMano = 1
                                PlayCarryAnim()
                                Notificar("Lleva la caja a la parte trasera de la camioneta", "success")
                            end
                        end
                    end
                end
                
                -- FASE 2: CARGAR EN CAMIONETA
                if Trabajo.cajasEnMano > 0 and Trabajo.vehiculo then
                    local veh = Trabajo.vehiculo
                    local trunkPos = GetOffsetFromEntityInWorldCoords(veh, 0.0, -3.0, 0.1)
                    local dist = #(pos - trunkPos)
                    
                    if dist < 6.0 then
                        wait = 0
                        DrawMarker(2, trunkPos.x, trunkPos.y, trunkPos.z + 0.25, 0,0,0, 0,0,0, 0.45,0.45,0.45, 50,255,50,180, false, true, 2, false, false, false, false)
                        
                        if dist < 1.6 then
                            Texto3D(vector3(trunkPos.x, trunkPos.y, trunkPos.z + 0.05), "[E] Guardar caja en camioneta")
                            
                            if IsControlJustReleased(0, 38) then
                                RequestAnimDict("pickup_object")
                                while not HasAnimDictLoaded("pickup_object") do Wait(5) end
                                TaskPlayAnim(ped, "pickup_object", "pickup_low", 8.0, -8.0, 800, 0, 0, false, false, false)
                                
                                Wait(900)
                                LimpiarProp()
                                Trabajo.cajasEnMano = 0
                                Trabajo.cajasEnCamioneta = Trabajo.cajasEnCamioneta + 1
                                
                                local faltan = #Config.Puntos.entregasCajas - Trabajo.cajasEnCamioneta
                                if faltan > 0 then
                                    Notificar("Caja guardada ("..Trabajo.cajasEnCamioneta.."/"..#Config.Puntos.entregasCajas..")", "success")
                                else
                                    Notificar("¡Todas las cajas cargadas! Empieza la ruta.", "success")
                                    Trabajo.punto = 1
                                    CrearBlip(Config.Puntos.entregasCajas[1].arrival, "Entrega 1")
                                end
                            end
                        end
                    end
                end
            end
            
            -- FASE 3: ENTREGAS DE CAJAS
            if Trabajo.cajasEnCamioneta > 0 and Trabajo.punto > 0 and Trabajo.punto <= #Config.Puntos.entregasCajas then
                local entrega = Config.Puntos.entregasCajas[Trabajo.punto]
                local distArrival = #(pos - entrega.arrival)
                
                if distArrival < 20 then
                    wait = 0
                    DrawMarker(2, entrega.arrival.x, entrega.arrival.y, entrega.arrival.z + 0.5, 0,0,0, 0,0,0, 0.65,0.65,0.65, 255,50,50,100, false, true, 2, false, false, false, false)
                end
                
                -- TOMAR CAJA DESDE LA CAMIONETA
                if Trabajo.cajasEnMano == 0 and Trabajo.vehiculo then
                    local veh = Trabajo.vehiculo
                    local trunkPos = GetOffsetFromEntityInWorldCoords(veh, 0.0, -3.0, 0.1)
                    local distTrunk = #(pos - trunkPos)
                    
                    if distTrunk < 6 then
                        wait = 0
                        if distTrunk < 1.6 then
                            Texto3D(vector3(trunkPos.x, trunkPos.y, trunkPos.z + 0.05),
                                "[E] Tomar caja de la camioneta ("..Trabajo.cajasEnCamioneta.." restantes)")
                            
                            if IsControlJustReleased(0, 38) then
                                local propHash = GetHashKey(Config.Props.boxProp)
                                RequestModel(propHash)
                                while not HasModelLoaded(propHash) do Wait(5) end
                                
                                local obj = CreateObject(propHash, pos.x, pos.y, pos.z, true, true, true)
                                AttachEntityToEntity(obj, ped, GetPedBoneIndex(ped, 28422), 0.0, -0.15, -0.25, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
                                Trabajo.propEnMano = obj
                                Trabajo.cajasEnMano = 1
                                PlayCarryAnim()
                                Notificar("Camina hasta la puerta para entregar la caja", "success")
                            end
                        end
                    end
                end
                
                -- ENTREGAR EN LA PUERTA
                if Trabajo.cajasEnMano == 1 then
                    local distPuerta = #(pos - entrega.delivery)
                    
                    if distPuerta < 4 then
                        wait = 0
                        DrawMarker(2, entrega.delivery.x, entrega.delivery.y, entrega.delivery.z + 0.3, 0,0,0, 0,0,0, 0.35,0.35,0.35, 255,50,50,150, false, true, 2, false, false, false, false)
                        
                        if distPuerta < 1.5 then
                            Texto3D(vector3(entrega.delivery.x, entrega.delivery.y, entrega.delivery.z + 0.3),
                                "[E] Dejar caja en la puerta")
                            
                            if IsControlJustReleased(0, 38) then
                                RequestAnimDict("pickup_object")
                                while not HasAnimDictLoaded("pickup_object") do Wait(5) end
                                TaskPlayAnim(ped, "pickup_object", "pickup_low", 8.0, -8.0, 800, 0, 0, false, false, false)
                                
                                Wait(900)
                                DetachEntity(Trabajo.propEnMano, true, true)
                                PlaceObjectOnGroundProperly(Trabajo.propEnMano)
                                Wait(300)
                                LimpiarProp()
                                
                                Trabajo.cajasEnMano = 0
                                Trabajo.cajasEnCamioneta = Trabajo.cajasEnCamioneta - 1
                                
                                Notificar("Entrega completada ("..Trabajo.punto.."/"..#Config.Puntos.entregasCajas..")", "success")
                                
                                Trabajo.punto = Trabajo.punto + 1
                                
                                if Trabajo.punto > #Config.Puntos.entregasCajas then
                                    CrearBlip(Config.Empresa.devolverVehiculo, "Devolver vehículo")
                                    Notificar("Todas las entregas hechas. Devuelve la camioneta.", "success")
                                else
                                    CrearBlip(Config.Puntos.entregasCajas[Trabajo.punto].arrival, "Entrega "..Trabajo.punto)
                                end
                            end
                        end
                    end
                end
            end
            
            -- FASE 4: DEVOLVER VEHÍCULO (COMÚN PARA AMBOS TRABAJOS)
            if Trabajo.punto > #Config.Puntos.entregasCajas then
                local dist = #(pos - Config.Empresa.devolverVehiculo)
                
                if dist < 15 then
                    wait = 0
                    DrawMarker(2, Config.Empresa.devolverVehiculo.x, Config.Empresa.devolverVehiculo.y, Config.Empresa.devolverVehiculo.z + 0.3,
                        0,0,0, 0,0,0, 0.8,0.8,0.8, 255,255,0,100, false, true, 2, false, false, false, false)
                    
                    if dist < 3 then
                        Texto3D(vector3(Config.Empresa.devolverVehiculo.x, Config.Empresa.devolverVehiculo.y, Config.Empresa.devolverVehiculo.z+0.5),
                            "[E] Devolver vehículo")
                        
                        if IsControlJustReleased(0, 38) then
                            local veh = GetVehiclePedIsIn(ped, false)
                            
                            if veh ~= 0 then
                                local plate = string.gsub(GetVehicleNumberPlateText(veh), "%s+", ""):upper()
                                local plateTrabajo = string.gsub(Trabajo.placa or "", "%s+", ""):upper()
                                
                                if plate == plateTrabajo then
                                    TriggerServerEvent('sh-entregas:entregarPago', Trabajo.job, Trabajo.precio, Trabajo.xp)
                                    Notificar("¡Trabajo terminado! $"..Trabajo.precio.." ganados", "success")
                                    
                                    LimpiarProp()
                                    SetEntityAsMissionEntity(veh, true, true)
                                    DeleteEntity(veh)
                                    if DoesEntityExist(veh) then DeleteVehicle(veh) end
                                    
                                    Trabajo.vehiculo = nil
                                    Trabajo.placa = nil
                                    RestaurarRopaTrabajo()
                                    
                                    if Trabajo.blip then
                                        RemoveBlip(Trabajo.blip)
                                        Trabajo.blip = nil
                                    end
                                    
                                    Trabajo.activo = false
                                    Trabajo.job = nil
                                    Trabajo.punto = 0
                                    Trabajo.cajasEnMano = 0
                                    Trabajo.cajasEnCamioneta = 0
                                    
                                    break
                                else
                                    Notificar("Este no es tu vehículo de trabajo", "error")
                                end
                            else
                                Notificar("Debes estar en el vehículo", "error")
                            end
                        end
                    end
                end
            end
            
            Wait(wait)
        end
    end)
end

function StartWezel()
    local veh = CrearVehiculo('wezel')
    if not veh then
        Trabajo.activo = false
        return
    end
    CrearBlip(Config.Puntos.recogerWezel, "Recoger periódicos")
    Notificar("Ve a recoger " .. #Config.Puntos.entregasWezel .. " periódicos", "success")
    
    CreateThread(function()
        while Trabajo.activo and Trabajo.job == 'wezel' do
            local ped = PlayerPedId()
            local pos = GetEntityCoords(ped)
            local wait = 1000
            
            -- FASE 1: RECOGER PERIÓDICOS
            if Trabajo.periodicosEnCamioneta < #Config.Puntos.entregasWezel then
                local dist = #(pos - Config.Puntos.recogerWezel)
                if dist < 10 then
                    wait = 0
                    DrawMarker(2, Config.Puntos.recogerWezel.x, Config.Puntos.recogerWezel.y, Config.Puntos.recogerWezel.z - 0.2, 0,0,0, 0,0,0, 0.6,0.6,0.6, 255,50,50,100, false, true, 2, false, false, false, false)
                    if dist < 2 then
                        local faltan = #Config.Puntos.entregasWezel - Trabajo.periodicosEnCamioneta
                        Texto3D(vector3(Config.Puntos.recogerWezel.x, Config.Puntos.recogerWezel.y, Config.Puntos.recogerWezel.z+0.5), "[E] Recoger periódico ("..faltan.." faltan)")
                        if IsControlJustReleased(0, 38) then
                            if Trabajo.periodicosEnMano == 0 then
                                -- Crear prop CORRECTO del periódico (ng_proc_paper_news_meteor)
                                LimpiarProp()
                                local propHash = GetHashKey(Config.Props.newspaperProp) -- 'ng_proc_paper_news_meteor'
                                RequestModel(propHash)
                                while not HasModelLoaded(propHash) do Wait(5) end
                                
                                local obj = CreateObject(propHash, pos.x, pos.y, pos.z, true, true, true)
                                AttachEntityToEntity(obj, ped, GetPedBoneIndex(ped, 28422), 0.0, -0.05, -0.15, 0.0, 0.0, 90.0, true, true, false, true, 1, true)
                                Trabajo.propEnMano = obj
                                
                                Trabajo.periodicosEnMano = 1
                                PlayCarryAnim()
                                Notificar("Lleva el periódico a la parte trasera de la camioneta", "success")
                            end
                        end
                    end
                end
                
-- FASE 2: CARGAR EN LA CAMIONETA REAL (Corregida)
if Trabajo.periodicosEnMano > 0 and Trabajo.vehiculo then
    local ped = PlayerPedId()
    local veh = Trabajo.vehiculo

    -- Offset TRASERO correcto para Rumpo (entre -3.0 y -3.5)
    local trunkPos = GetOffsetFromEntityInWorldCoords(veh, 0.0, -3.3, 0.1)

    local dist = #(pos - trunkPos)

    if dist < 6.0 then
        wait = 0

        -- Marker en parte trasera real
        DrawMarker(
            2,
            trunkPos.x, trunkPos.y, trunkPos.z - 0.95,
            0,0,0, 0,0,0,
            0.45,0.45,0.45,
            50,255,50,180,
            false, true, 2, false, false, false, false
        )

        if dist < 1.6 then
            Texto3D(
                vector3(trunkPos.x, trunkPos.y, trunkPos.z + 0.05),
                "[E] Guardar periódico en la camioneta"
            )

            if IsControlJustReleased(0, 38) then
                
                -- animación correcta
                RequestAnimDict("pickup_object")
                while not HasAnimDictLoaded("pickup_object") do Wait(5) end
                TaskPlayAnim(ped, "pickup_object", "pickup_low", 8.0, -8.0, 800, 0, 0, false, false, false)
                
                Wait(900)

                -- eliminar prop
                LimpiarProp()
                Trabajo.periodicosEnMano = 0
                Trabajo.periodicosEnCamioneta = Trabajo.periodicosEnCamioneta + 1

                local faltan = #Config.Puntos.entregasWezel - Trabajo.periodicosEnCamioneta

                if faltan > 0 then
                    Notificar("Periódico guardado ("..Trabajo.periodicosEnCamioneta.."/"..#Config.Puntos.entregasWezel..")", "success")
                else
                    Notificar("¡Todos los periódicos cargados! Empieza la ruta.", "success")
                    Trabajo.punto = 1
                    CrearBlip(Config.Puntos.entregasWezel[1].arrival, "Entrega 1")
                end
            end
        end
    end
end

end
            
            -- FASE 3: ENTREGA REALISTA (con misma lógica que FASE 2)
if Trabajo.periodicosEnCamioneta > 0 and Trabajo.punto > 0 and Trabajo.punto <= #Config.Puntos.entregasWezel then
    local ped = PlayerPedId()
    local entrega = Config.Puntos.entregasWezel[Trabajo.punto]

    ----------------------------------------------------
    -- 3A: LLEGAR AL PUNTO DE ARRIVAL (PARA GUIAR)
    ----------------------------------------------------
    local distArrival = #(pos - entrega.arrival)

    if distArrival < 20 then
        wait = 0
        DrawMarker(
            2,
            entrega.arrival.x, entrega.arrival.y, entrega.arrival.z + 0.5,
            0,0,0, 0,0,0,
            0.65, 0.65, 0.65,
            255,50,50,100,
            false, true, 2, false, false, false, false
        )

    end

    ----------------------------------------------------
    -- 3B: TOMAR PERIÓDICO DESDE LA CAMIONETA
    ----------------------------------------------------
    if Trabajo.periodicosEnMano == 0 and Trabajo.vehiculo then
        local veh = Trabajo.vehiculo
        local trunkPos = GetOffsetFromEntityInWorldCoords(veh, 0.0, -3.3, 0.1)

        local distTrunk = #(pos - trunkPos)

        if distTrunk < 6 then
            wait = 0



            if distTrunk < 1.6 then
                Texto3D(vector3(trunkPos.x, trunkPos.y, trunkPos.z + 0.05),
                    "[E] Tomar periódico de la camioneta ("..Trabajo.periodicosEnCamioneta.." restantes)")

                if IsControlJustReleased(0, 38) then

                    -- crear prop periódico
                    local propHash = GetHashKey(Config.Props.newspaperProp)
                    RequestModel(propHash)
                    while not HasModelLoaded(propHash) do Wait(5) end

                    local obj = CreateObject(propHash, pos.x, pos.y, pos.z, true, true, true)
                    AttachEntityToEntity(
                        obj, ped, GetPedBoneIndex(ped, 28422),
                        0.0, -0.05, -0.15,
                        0.0, 0.0, 90.0,
                        true, true, false, true, 1, true
                    )
                    Trabajo.propEnMano = obj
                    Trabajo.periodicosEnMano = 1
                    PlayCarryAnim()
                    Notificar("Camina hasta la puerta para entregar el periódico", "success")
                end
            end
        end
    end

    ----------------------------------------------------
    -- 3C: ENTREGAR EN LA PUERTA
    ----------------------------------------------------
    if Trabajo.periodicosEnMano == 1 then
        local distPuerta = #(pos - entrega.delivery)

        if distPuerta < 4 then
            wait = 0

            DrawMarker(
                2,
                entrega.delivery.x, entrega.delivery.y, entrega.delivery.z + 0.3,
                0,0,0, 0,0,0,
                0.35,0.35,0.35,
                255,50,50,150,
                false,true,2,false,false,false,false
            )

            if distPuerta < 1.5 then
                Texto3D(vector3(entrega.delivery.x, entrega.delivery.y, entrega.delivery.z + 0.3),
                    "[E] Dejar periódico en la puerta")

                if IsControlJustReleased(0, 38) then
                    -- animación
                    RequestAnimDict("pickup_object")
                    while not HasAnimDictLoaded("pickup_object") do Wait(5) end
                    TaskPlayAnim(ped, "pickup_object", "pickup_low", 8.0, -8.0, 800, 0, 0, false, false, false)

                    Wait(900)

                    -- soltar prop
                    DetachEntity(Trabajo.propEnMano, true, true)
                    PlaceObjectOnGroundProperly(Trabajo.propEnMano)
                    Wait(300)
                    LimpiarProp()

                    Trabajo.periodicosEnMano = 0
                    Trabajo.periodicosEnCamioneta -= 1

                    Notificar("Entrega completada ("..Trabajo.punto.."/"..#Config.Puntos.entregasWezel..")", "success")

                    -- siguiente punto
                    Trabajo.punto += 1

                    if Trabajo.punto > #Config.Puntos.entregasWezel then
                        CrearBlip(Config.Empresa.devolverVehiculo, "Devolver vehículo")
                        Notificar("Todas las entregas hechas. Devuelve la camioneta.", "success")
                    else
                        CrearBlip(Config.Puntos.entregasWezel[Trabajo.punto].arrival, "Entrega "..Trabajo.punto)
                    end
                end
            end
        end
    end
end
            
-- FASE 4: DEVOLVER VEHÍCULO (CORREGIDO)
if Trabajo.punto > #Config.Puntos.entregasWezel then
    local dist = #(pos - Config.Empresa.devolverVehiculo)

    if dist < 15 then
        wait = 0
        DrawMarker(2, Config.Empresa.devolverVehiculo.x, Config.Empresa.devolverVehiculo.y, Config.Empresa.devolverVehiculo.z + 0.3,
            0,0,0, 0,0,0, 0.8,0.8,0.8, 255,255,0,100, false, true, 2, false, false, false, false)

        if dist < 3 then
            Texto3D(vector3(Config.Empresa.devolverVehiculo.x, Config.Empresa.devolverVehiculo.y, Config.Empresa.devolverVehiculo.z+0.5),
                "[E] Devolver vehículo")

            if IsControlJustReleased(0, 38) then
                local veh = GetVehiclePedIsIn(ped, false)

                if veh ~= 0 then
                    local plate = string.gsub(GetVehicleNumberPlateText(veh), "%s+", ""):upper()
                    local plateTrabajo = string.gsub(Trabajo.placa or "", "%s+", ""):upper()

                    if plate == plateTrabajo then

TriggerServerEvent('sh-entregas:entregarPago', Trabajo.job, Trabajo.precio, Trabajo.xp)
Notificar("¡Trabajo terminado! $"..Trabajo.precio.." ganados", "success")

LimpiarProp()

-- DESPAWN SEGURO
SetEntityAsMissionEntity(veh, true, true)
DeleteEntity(veh)
if DoesEntityExist(veh) then DeleteVehicle(veh) end

Trabajo.vehiculo = nil
Trabajo.placa = nil

-- 🔥 RESTAURAR ROPA DEL TRABAJO 🔥
RestaurarRopaTrabajo()

if Trabajo.blip then
    RemoveBlip(Trabajo.blip)
    Trabajo.blip = nil
end

Trabajo.activo = false
Trabajo.job = nil
Trabajo.punto = 0
Trabajo.periodicosEnMano = 0
Trabajo.periodicosEnCamioneta = 0

break

                    else
                        Notificar("Este no es tu vehículo de trabajo", "error")
                    end
                else
                    Notificar("Debes estar en el vehículo", "error")
                end
            end
        end
    end
end

            
            Wait(wait)
        end
    end)
end

function Texto3D(coords, texto)
    local onScreen, x, y = World3dToScreen2d(coords.x, coords.y, coords.z)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)

        -- COLOR AMARILLO
        SetTextColour(255, 215, 0, 255)

        -- EFECTOS
        SetTextOutline()
        SetTextDropShadow(2, 0, 0, 0, 200)

        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(texto)
        DrawText(x, y)
    end
end


RegisterCommand(Config.ComandoCancelar, function()
    if Trabajo.activo then
        LimpiarProp()
        EliminarVehiculo()
        if Trabajo.blip then RemoveBlip(Trabajo.blip) Trabajo.blip = nil end
        
        -- LIMPIAR TODAS LAS VARIABLES
        Trabajo.activo = false
        Trabajo.job = nil
        Trabajo.punto = 0
        Trabajo.periodicosEnMano = 0
        Trabajo.periodicosEnCamioneta = 0
        Trabajo.cajasEnMano = 0
        Trabajo.cajasEnCamioneta = 0
        
        RestaurarRopaTrabajo()
        Notificar("Trabajo cancelado", "error")
    end
end)

CreateThread(function()
    local model = GetHashKey(Config.Empresa.ped)
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(0) end
    
    local ped = CreatePed(4, model, Config.Empresa.ubicacion.xyz, Config.Empresa.ubicacion.w, false, false)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)

    ---------------------------------------------------
    -- 🔥 SISTEMA DUAL DE TARGET: OX O QB 🔥
    ---------------------------------------------------
    if Config.UseOxTarget then
        
-- =====================================
--        🟦 USAR OX_TARGET
-- =====================================
exports.ox_target:addLocalEntity(ped, {
    {
        name = 'iniciar_trabajo_entregas',
        label = 'Iniciar Trabajo',
        icon = 'fa-solid fa-briefcase',
        onSelect = function()
            AbrirInterfaz()
        end
    },
    {
        name = 'cancelar_trabajo_entregas',
        label = 'Cancelar Trabajo',
        icon = 'fa-solid fa-xmark',
        onSelect = function()
            if Trabajo.activo then
                -- DETECTAR SI ES TRABAJO TECNO
                if Trabajo.job == 'tecno' then
                    -- Para tecno: llamar a la función que SI limpia todo
                    local resource = GetCurrentResourceName()
                    if exports[resource] and exports[resource].FinalizarTecno then
                        exports[resource].FinalizarTecno()  -- ✅ ESTA ES LA FUNCIÓN CORRECTA
                    end
                    -- También limpiar las variables del trabajo principal
                    Trabajo.activo = false
                    Trabajo.job = nil
                    Trabajo.precio = 0
                    Trabajo.xp = 0
                    Trabajo.punto = 0
                    Trabajo.vehiculo = nil
                    Trabajo.placa = nil
                    Trabajo.periodicosEnMano = 0
                    Trabajo.periodicosEnCamioneta = 0
                    Trabajo.cajasEnMano = 0
                    Trabajo.cajasEnCamioneta = 0
                    if Trabajo.blip then RemoveBlip(Trabajo.blip) Trabajo.blip = nil end
                    
                else
                    -- Para wezel y cajas, limpieza normal
                    LimpiarProp()
                    EliminarVehiculo()
                    RestaurarRopaTrabajo()
                    if Trabajo.blip then RemoveBlip(Trabajo.blip) Trabajo.blip = nil end
                    Trabajo.activo = false
                    Notificar("Trabajo cancelado", "error")
                end
            else
                Notificar("No tienes trabajo activo", "error")
            end
        end
    }
})

    else

-- =====================================
--        🟩 USAR QB-TARGET
-- =====================================
exports['qb-target']:AddTargetEntity(ped, {
    options = {
        {
            label = 'Iniciar Trabajo',
            icon = 'fas fa-briefcase',
            action = function() AbrirInterfaz() end
        },
        {
            label = 'Cancelar Trabajo',
            icon = 'fas fa-times',
            action = function()
                if Trabajo.activo then
                    -- DETECTAR SI ES TRABAJO TECNO
                    if Trabajo.job == 'tecno' then
                        -- Para tecno: llamar a la función que SI limpia todo
                        local resource = GetCurrentResourceName()
                        if exports[resource] and exports[resource].FinalizarTecno then
                            exports[resource].FinalizarTecno()  -- ✅ ESTA ES LA FUNCIÓN CORRECTA
                        end
                        -- También limpiar las variables del trabajo principal
                        Trabajo.activo = false
                        Trabajo.job = nil
                        Trabajo.precio = 0
                        Trabajo.xp = 0
                        Trabajo.punto = 0
                        Trabajo.vehiculo = nil
                        Trabajo.placa = nil
                        Trabajo.periodicosEnMano = 0
                        Trabajo.periodicosEnCamioneta = 0
                        Trabajo.cajasEnMano = 0
                        Trabajo.cajasEnCamioneta = 0
                        if Trabajo.blip then RemoveBlip(Trabajo.blip) Trabajo.blip = nil end
                        
                    else
                        -- Para wezel y cajas, limpieza normal
                        LimpiarProp()
                        EliminarVehiculo()
                        RestaurarRopaTrabajo()
                        if Trabajo.blip then RemoveBlip(Trabajo.blip) Trabajo.blip = nil end
                        Trabajo.activo = false
                        Notificar("Trabajo cancelado", "error")
                    end
                else
                    Notificar("No tienes trabajo activo", "error")
                end
            end
        }
    },
    distance = 2.0
})
    end
    ---------------------------------------------------
    -- FIN DEL SISTEMA DUAL DE TARGET
    ---------------------------------------------------

    -- Blip del negocio
    local blip = AddBlipForCoord(Config.Empresa.ubicacion.xyz)
    SetBlipSprite(blip, 85)
    SetBlipColour(blip, 5)
    SetBlipScale(blip, 0.6)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Servicios de Entrega")
    EndTextCommandSetBlipName(blip)
end)

-- Evento para limpiar cuando tecno finaliza - DEBE ESTAR REGISTRADO
RegisterNetEvent('sh-entregas:tecnoFinalizado')
AddEventHandler('sh-entregas:tecnoFinalizado', function()
    
    -- Limpiar variables del trabajo
    Trabajo.activo = false
    Trabajo.job = nil
    Trabajo.precio = 0
    Trabajo.xp = 0
    Trabajo.punto = 0
    Trabajo.vehiculo = nil
    Trabajo.placa = nil
    Trabajo.periodicosEnMano = 0
    Trabajo.periodicosEnCamioneta = 0
    Trabajo.cajasEnMano = 0
    Trabajo.cajasEnCamioneta = 0
    
    -- Limpiar blip si existe
    if Trabajo.blip then
        RemoveBlip(Trabajo.blip)
        Trabajo.blip = nil
    end
    
    -- Limpiar prop si existe
    if Trabajo.propEnMano and DoesEntityExist(Trabajo.propEnMano) then
        DeleteEntity(Trabajo.propEnMano)
        Trabajo.propEnMano = nil
    end
    
    -- Eliminar vehículo si existe (para tecno no debería tener, pero por si acaso)
    if Trabajo.vehiculo and DoesEntityExist(Trabajo.vehiculo) then
        SetEntityAsMissionEntity(Trabajo.vehiculo, true, true)
        DeleteVehicle(Trabajo.vehiculo)
        Trabajo.vehiculo = nil
        Trabajo.placa = nil
    end
    
    RestaurarRopaTrabajo()
    
end)

RegisterNetEvent('sh-entregas:forceOpenUI', AbrirInterfaz)
AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        LimpiarProp()
        EliminarVehiculo()
        RestaurarRopaTrabajo()
        if Trabajo.blip then RemoveBlip(Trabajo.blip) end
        SetNuiFocus(false, false)
    end
end)

