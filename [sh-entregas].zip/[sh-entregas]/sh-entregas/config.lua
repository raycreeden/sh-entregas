-- config.lua
Config = {}

-- Empresa / NPC que inicia el job
Config.Empresa = {
    ped = 's_m_m_postal_02', -- NPC que inicia el job
    ubicacion = vector4(1184.07, -3303.96, 6.1, 80.5), -- donde está el npc
    nombre = 'Servicios de Entrega SH',
    tamanoBlip = 0.7,
    colorBlip = 5,
    spriteBlip = 85,
    -- puntos para devolver vehiculo (mismo lugar definido en tu pedido)
    ubicacionVehiculo = {
        -- vehiculos por job (spawn de la camioneta)
        wezel = vector4(1179.1, -3322.46, 6.05, 87.82), -- rumpo
        cajas = vector4(1178.53, -3304.16, 5.82, 88.86)  -- pony
    },
    -- lugar donde devolver la camioneta al finalizar
    devolverVehiculo = vector3(1177.03, -3328.07, 5.03)
}

-- Si true usa ox_target; si false usa qb-target.
-- (por tu pedido: true => ox_target, false => qb-target)
Config.UseOxTarget = false

-- Comando para cancelar trabajo
Config.ComandoCancelar = 'cancelarentrega'

-- Vehiculos por job (model string)
Config.Vehiculos = {
    wezel = 'rumpo',        -- camioneta de newspapers
    cajas  = 'pony'         -- camioneta para cajas
    -- tecno por ahora no entrega vehiculo (queda en la UI pero sin lógica)
}

-- Hash / props / anims para recolección y carga
Config.Props = {
    newspaperProp = 'ng_proc_paper_news_meteor', -- prop para periódicos (hash en cliente)
    newspaperPropHash = 1162065741,
    boxProp = 'prop_hat_box_06'
}

Config.Anims = {
    carryIdle = { dict = 'anim@heists@box_carry@', name = 'idle' }, -- para cargar papel
    pickup = { dict = 'pickup_object', name = 'pickup_low' } -- para entrega/colocar
}

-- Puntos de recolección / carga / entregas (están los dos puntos por entrega)
Config.Puntos = {
    -- lugar para recoger periódicos (wezel) antes de cargarlos en la camioneta
    recogerWezel = vector3(-536.88, -886.2, 25.45),
    cargarWezel = vector3(1174.23, -3311.2, 6.21), -- parte trasera (E para meter newspapers)

    -- entregas: cada entrada tiene arrivalPoint (donde debe llegar la camioneta) y deliveryPoint (puerta)
    entregasWezel = {
        { arrival = vector3(83.87, -1929.22, 19.61), delivery = vector3(73.1, -1938.16, 19.99) },
        { arrival = vector3(250.47, -1694.17, 28.02), delivery = vector3(240.88, -1687.89, 28.7) },
        { arrival = vector3(-21.02, -1582.44, 29.16), delivery = vector3(-27.72, -1564.75, 30.68) },
        { arrival = vector3(-146.81, -1713.1, 30.02), delivery = vector3(-141.95, -1697.63, 30.77) },
        { arrival = vector3(-57.07, -1772.74, 29.01), delivery = vector3(-55.41, -1755.9, 29.44) },
        { arrival = vector3(-1125.18, -1577.54, 4.21), delivery = vector3(-1114.67, -1577.73, 4.54) },
        { arrival = vector3(-1240.43, -1725.17, 4.42), delivery = vector3(-1286.21, -1753.65, 3.71) },
        { arrival = vector3(-1354.48, -1149.28, 4.21), delivery = vector3(-1335.76, -1146.91, 6.73) },
        { arrival = vector3(-1877.49, -574.49, 11.63), delivery = vector3(-1883.27, -578.98, 11.82) },
        { arrival = vector3(-858.23, 519.07, 90.11), delivery = vector3(-848.48, 508.56, 90.82) },
    },

    -- Cajas
    recogerCajas = vector3(1179.38, -3312.74, 5.03),
    cargarCajas = vector3(1181.13, -3304.18, 6.15),

    entregasCajas = {
        { arrival = vector3(1219.92, -3209.4, 5.88), delivery = vector3(1219.17, -3200.04, 5.79) },
        { arrival = vector3(1250.79, -3261.88, 4.83), delivery = vector3(1240.52, -3263.27, 4.53) },
        { arrival = vector3(165.9, -3056.56, 5.89), delivery = vector3(155.46, -3057.0, 7.03) },
        { arrival = vector3(663.68, -2666.38, 6.08), delivery = vector3(671.94, -2667.57, 6.08) },
        { arrival = vector3(1015.53, -2515.47, 28.3), delivery = vector3(1019.25, -2511.54, 28.48) },
        { arrival = vector3(916.98, -2169.32, 30.32), delivery = vector3(912.16, -2174.23, 30.49) },
        { arrival = vector3(895.14, -1735.6, 30.34), delivery = vector3(899.12, -1721.72, 32.25) },
        { arrival = vector3(-666.54, -2370.97, 13.94), delivery = vector3(-663.94, -2380.5, 13.94) },
        { arrival = vector3(-1067.28, -2063.73, 13.29), delivery = vector3(-1077.21, -2079.42, 13.29) },
        { arrival = vector3(-856.05, -1219.88, 6.25), delivery = vector3(-862.62, -1227.52, 6.47) },
        { arrival = vector3(2706.43, 3445.91, 55.75), delivery = vector3(2709.98, 3455.11, 56.32) },
        { arrival = vector3(139.97, 6365.06, 31.38), delivery = vector3(146.85, 6366.48, 31.53) }

    }
}

-- Recompensas y niveles (ejemplo, puedes editar)
Config.Trabajos = {
    ajustes = {
        wezel = {
            { nivel = 1, precio = 25, xp = 10 },
            { nivel = 2, precio = 50, xp = 12 },
            { nivel = 3, precio = 75, xp = 15 },
            { nivel = 4, precio = 100, xp = 19 },
            { nivel = 5, precio = 125, xp = 23 },
            { nivel = 6, precio = 150, xp = 27 },
            { nivel = 7, precio = 175, xp = 31 },
            { nivel = 8, precio = 200, xp = 35 },
            { nivel = 9, precio = 225, xp = 39 },
            { nivel = 10, precio = 250, xp = 44 }
        },
        cajas = {
            { nivel = 1, precio = 70, xp = 12 },
            { nivel = 2, precio = 100, xp = 15 },
            { nivel = 3, precio = 130, xp = 18 },
            { nivel = 4, precio = 145, xp = 21 },
            { nivel = 5, precio = 160, xp = 24 },
            { nivel = 6, precio = 175, xp = 27 },
            { nivel = 7, precio = 210, xp = 30 },
            { nivel = 8, precio = 235, xp = 33 },
            { nivel = 9, precio = 255, xp = 35 },
            { nivel = 10, precio = 285, xp = 38 }
        },
        tecno = {
            { nivel = 1, precio = 120, xp = 20 },
            { nivel = 2, precio = 170, xp = 25 },
            { nivel = 3, precio = 220, xp = 30 },
            { nivel = 4, precio = 270, xp = 35 },
            { nivel = 5, precio = 320, xp = 40 },
            { nivel = 6, precio = 370, xp = 45 },
            { nivel = 7, precio = 420, xp = 50 },
            { nivel = 8, precio = 470, xp = 55 },
            { nivel = 9, precio = 520, xp = 60 },
            { nivel = 10, precio = 570, xp = 65 }
        },
        niveles = {
            { nivel = 1, siguienteNivel = 200 },
            { nivel = 2, siguienteNivel = 400 },
            { nivel = 3, siguienteNivel = 800 },
            { nivel = 4, siguienteNivel = 1200 },
            { nivel = 5, siguienteNivel = 1600 },
            { nivel = 6, siguienteNivel = 2000 },
            { nivel = 7, siguienteNivel = 2400 },
            { nivel = 8, siguienteNivel = 2800 },
            { nivel = 9, siguienteNivel = 3200 },
            { nivel = 10, siguienteNivel = 3600 }
        }
    },

    -- número de pasos por cada job (para la UI)
    steps = {
        wezelnStep = #Config.Puntos.entregasWezel * 2, -- ejemplo: recolección + entregas? (UI usa este valor)
        boxStep = #Config.Puntos.entregasCajas * 2,
        techStep = Config.Tecno and Config.Tecno.config and Config.Tecno.config.totalProps or 50
    }
}

-- Textos en español
Config.Textos = {
    yaTrabajas = "Ya estás en un trabajo",
    siguiente = "Ve al siguiente punto. Te quedan %d puntos.",
    sinVehiculo = "Debes salir del vehículo",
    finalizado = "Trabajo finalizado, vuelve a la empresa",
    vehiculoFinalizado = "Vehículo devuelto correctamente",
    vehiculoIncorrecto = "Este no es tu vehículo de trabajo",
    trabajoCancelado = "Trabajo cancelado",
    primeroIniciar = "Primero debes iniciar el trabajo",
    cargarE = "E para cargar",
    descargarE = "E para bajar los paquetes/periodicos",
    entregaRealizada = "Entrega realizada. Ve al siguiente punto.",
    -- NUEVOS TEXTOS PARA TECNO
    tecno_iniciado = "¡Trabajo iniciado! Ve a los camiones para recolectar mercadería.",
    tecno_recolectar = "[E] Recolectar mercadería",
    tecno_recogida = "Guarda Correctamente el Articulo Recogido",
    tecno_entregar = "[E] Entregar en %s",
    tecno_entrega_correcta = "✅ ¡Mercadería entregada correctamente! +$%d",
    tecno_entrega_incorrecta = "❌ Mercadería entregada en lugar incorrecto",
    tecno_props_restantes = "Mercadería restante: %d/%d",
    tecno_completado = "¡Trabajo completado! Ganaste $%d",
    tecno_salir_vehiculo = "Debes salir del vehículo para recolectar",
    tecno_manos_llenas = "Ya tienes mercadería en las manos",
    tecno_sin_mercaderia = "No tienes mercadería para entregar"
}

-- Mods de vehiculos opcionales
Config.VehicleMods = {
    ['pony'] = {
        primaryColor = 154,
        secondaryColor = 40,
        rimColor = 131,
        wheelType = 10,
        wheelIndex = 10,
        livery = 1,
        mods = { [0]=0, [1]=1, [2]=4, [3]=0, [4]=4, [6]=9, [7]=8, [27]=2, [35]=0, [43]=4, [44]=3 },
        extras = { [1]=true, [2]=true, [3]=false, [4]=true, [5]=true, [6]=true }
    },
    ['rumpo'] = {
        livery = 0,
        primaryColor = 154,
        secondaryColor = 154,
        rimColor = 131,
        wheelType = 10,
        wheelIndex = 10,
         mods = { [0]=0, [1]=1, [2]=4, [3]=0, [4]=4, [6]=9, [7]=8, [27]=2, [35]=0, [43]=4, [44]=3 },
        extras = { [1]=true, [2]=true, [3]=false, [4]=true, [5]=true, [6]=true }
    },
}


Config.RopaTrabajo = { 
    male = { 
        ['accessory'] = { component = 7, drawable = 0, texture = 0 },
        ['hat'] = { prop = 0, drawable = 176, texture = 0 },
        ['torso2'] = { component = 11, drawable = 45, texture = 1 },
        ['t-shirt'] = { component = 8, drawable = 15, texture = 0 },
        ['arms'] = { component = 3, drawable = 41, texture = 0 },
        ['pants'] = { component = 4, drawable = 15, texture = 0 },
        ['shoes'] = { component = 6, drawable = 1, texture = 7 },
        ['bag'] = { component = 5, drawable = 0, texture = 0 },
        ['decals'] = { component = 10, drawable = 0, texture = 0 },
        ['torso'] = { component = 9, drawable = 0, texture = 0 },
        ['mask'] = { component = 1, drawable = 0, texture = 0 },
        ['vest'] = { component = 9, drawable = 0, texture = 0 }
    },
    female = { 
        ['accessory'] = { component = 7, drawable = 0, texture = 0 },
        ['hat'] = { prop = 0, drawable = 129, texture = 2 },
        ['torso2'] = { component = 11, drawable = 245, texture = 7 },
        ['t-shirt'] = { component = 8, drawable = 15, texture = 0 },
        ['arms'] = { component = 3, drawable = 44, texture = 0 },
        ['pants'] = { component = 4, drawable = 27, texture = 2 },
        ['shoes'] = { component = 6, drawable = 1, texture = 4 },
        ['bag'] = { component = 5, drawable = 0, texture = 0 },
        ['decals'] = { component = 10, drawable = 0, texture = 0 },
        ['torso'] = { component = 9, drawable = 0, texture = 0 },
        ['mask'] = { component = 1, drawable = -1, texture = 0 },
        ['vest'] = { component = 9, drawable = 0, texture = 0 }
    }
}

-- ============================================================
-- NUEVA CONFIGURACIÓN PARA TECNO (TRABAJO DE DEPÓSITOS)
-- ============================================================
Config.Tecno = {
    -- Puntos de recolección estáticos (en lugar de vehículos)
    puntosRecoleccion = {
        {
            nombre = "Punto de Recolección 1",
            posicion = vector3(1182.1, -3310.64, 6.28),
            maxProps = 25 -- máximo de props que puede contener
        },
        {
            nombre = "Punto de Recolección 2",
            posicion = vector3(1212.03, -3329.04, 6.03),
            maxProps = 25 -- máximo de props que puede contener
        }
    },
    
    -- Props y sus categorías
    props = {
        {prop = 'xm3_prop_xm3_box_wood03a', categoria = 'todas', nombre = "Caja de Madera"},
        {prop = 'prop_tshirt_box_01', categoria = 'medicamentos', nombre = "Caja de Camisetas"},
        {prop = 'prop_ball_box', categoria = 'hogar', nombre = "Caja de Pelotas"},
        {prop = 'v_ind_meatbox', categoria = 'alimentos_frescos', nombre = "Caja de Carnes"},
        {prop = 'prop_hat_box_04', categoria = 'jardineria', nombre = "Caja de Sombreros 04"},
        {prop = 'prop_hat_box_06', categoria = 'todas', nombre = "Caja de Sombreros 06"},
        {prop = 'prop_hat_box_01', categoria = 'jardineria', nombre = "Caja de Sombreros 01"},
        {prop = 'prop_cs_cardbox_01', categoria = 'hogar', nombre = "Caja de Cartón"},
        {prop = 'v_serv_abox_1', categoria = 'equipo_policial', nombre = "Caja de Servicio"},
        {prop = 'v_ind_cf_chckbox3', categoria = 'congelados', nombre = "Caja Congelada"},
        {prop = 'prop_horo_box_02', categoria = 'todas', nombre = "Caja de Relojes"},
        {prop = 'v_ret_csr_signtrismall', categoria = 'autopartes', nombre = "Señal de Auto"},
        {prop = 'ex_office_swag_electronic3', categoria = 'tecnologia', nombre = "Equipo Electrónico"},
        {prop = 'xs_propintxmas_tree_2018', categoria = 'hogar', nombre = "Árbol de Navidad"},
        {prop = 'prop_box_ammo06a', categoria = 'equipo_policial', nombre = "Caja de Munición 06"},
        {prop = 'prop_box_ammo01a', categoria = 'equipo_policial', nombre = "Caja de Munición 01"},
        {prop = 'prop_windowbox_b', categoria = 'jardineria', nombre = "Macetero B"},
        {prop = 'prop_windowbox_small', categoria = 'jardineria', nombre = "Macetero Pequeño"},
        {prop = 'reh_prop_reh_box_metal_01a', categoria = 'tecnologia', nombre = "Caja Metálica"},
        {prop = 'imp_prop_impexp_gearbox_01', categoria = 'autopartes', nombre = "Caja de Cambios"},
        {prop = 'ch_prop_casino_drone_02a', categoria = 'equipo_policial', nombre = "Dron de Casino"}
    },
    
    -- Depósitos para entregar (categorías)
    depositos = {
        {nombre = "Depósito de Tecnología", categoria = 'tecnologia', posicion = vector3(1190.51, -3325.28, 5.48)},
        {nombre = "Depósito de Informática", categoria = 'informatica', posicion = vector3(1205.13, -3325.28, 5.56)},
        {nombre = "Depósito de Articulos del Hogar", categoria = 'hogar', posicion = vector3(1218.51, -3325.28, 5.62)},
        {nombre = "Depósito de Jardineria", categoria = 'jardineria', posicion = vector3(1233.75, -3325.28, 5.5)},
        {nombre = "Depósito de Alimentos Frescos", categoria = 'alimentos_frescos', posicion = vector3(1240.08, -3298.11, 6.39)},
        {nombre = "Depósito de Congelados", categoria = 'congelados', posicion = vector3(1240.08, -3289.16, 6.34)},
        {nombre = "Depósito de Equipo Policial", categoria = 'equipo_policial', posicion = vector3(1240.08, -3272.78, 6.44)},
        {nombre = "Depósito de Autopartes", categoria = 'autopartes', posicion = vector3(1240.08, -3262.77, 6.38)},
        {nombre = "Depósito de Pinturas", categoria = 'pinturas', posicion = vector3(1234.03, -3235.86, 5.6)},
        {nombre = "Depósito de Medicamentos", categoria = 'medicamentos', posicion = vector3(1218.28, -3235.86, 5.34)}
    },
    
     -- Configuración del trabajo
    config = {
        totalProps = 50, -- Total de props a entregar
        pagoPorEntregaCorrecta = 25, -- Pago por entregar en depósito correcto
        pagoPorEntregaIncorrecta = 0, -- Pago por entregar en depósito incorrecto
        maxDistanciaInteraccion = 2.5, -- Distancia máxima para interactuar
        tiempoNotificacion = 5000, -- Tiempo que dura la notificación (ms)
        blipSprite = 478, -- Sprite del blip
        blipColor = 5, -- Color del blip
        blipScale = 0.6, -- Escala del blip
        blipSpriteRecoleccion = 478, -- Sprite para puntos de recolección
        blipColorRecoleccion = 5 -- Color para puntos de recolección
    }
}