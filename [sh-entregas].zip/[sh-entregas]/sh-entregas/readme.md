# Job de entregas # 
- Job personalizado de entregas de diferentes tipos, dejar periodicos, cajas y ordena los depositos - 
# QBCore - Qbox #