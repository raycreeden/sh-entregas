fx_version 'cerulean'
game 'gta5'
author 'SherlockCo'
lua54 'yes'

shared_script 'config.lua'
client_script 'client/client.lua'
server_script 'server/server.lua'
client_script 'client/deposito.lua'  -- NUEVO: cliente para tecno
server_script 'server/deposito.lua'  -- NUEVO: servidor para tecno

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua'
}

dependencies {
    'oxmysql'
}
